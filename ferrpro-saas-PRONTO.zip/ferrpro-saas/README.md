# FerrPro SaaS — Guia de Configuração

## 📁 Arquivos do Projeto

```
ferrpro-saas/
├── index.html    → Landing page (marketing)
├── login.html    → Login / Cadastro
├── app.html      → Aplicativo principal
└── README.md     → Este arquivo
```

---

## ⚙️ PASSO A PASSO PARA CONFIGURAR

### PASSO 1 — Criar conta no Supabase (grátis)

1. Acesse **https://supabase.com**
2. Clique em **"Start your project"**
3. Faça login com GitHub ou Google
4. Clique em **"New Project"**
5. Preencha:
   - **Name:** ferrpro
   - **Database Password:** (anote essa senha!)
   - **Region:** South America (São Paulo)
6. Clique **"Create new project"**
7. Aguarde ~2 minutos para criar

---

### PASSO 2 — Pegar as credenciais

1. No painel do Supabase, vá em **Settings → API**
2. Copie:
   - **Project URL** (ex: `https://xyzabc.supabase.co`)
   - **anon/public key** (chave longa)

---

### PASSO 3 — Criar as tabelas (SQL)

1. No Supabase, vá em **SQL Editor**
2. Clique em **"New query"**
3. Cole e execute o SQL do arquivo `schema.sql`

---

### PASSO 4 — Inserir as credenciais nos arquivos

Abra **login.html** e **app.html** e substitua:

```js
const SUPABASE_URL = 'SUA_SUPABASE_URL';
const SUPABASE_KEY = 'SUA_SUPABASE_ANON_KEY';
```

Por suas credenciais reais:

```js
const SUPABASE_URL = 'https://xyzabc.supabase.co';
const SUPABASE_KEY = 'eyJhbGc...sua_chave_aqui';
```

---

### PASSO 5 — Publicar no Netlify

1. Acesse **https://app.netlify.com/drop**
2. **Selecione os 3 arquivos** (index.html, login.html, app.html) e arraste juntos
3. Aguarde gerar o link
4. Pronto! ✅

---

## 💰 COMO COBRAR ASSINATURA

### Opção 1 — Manual (começo)
- Receba via **PIX** ou transferência
- Libere acesso manualmente

### Opção 2 — Hotmart (sem programar)
1. Crie conta em **hotmart.com**
2. Cadastre o produto (ex: FerrPro Pro — R$99/mês)
3. Após pagamento, envie o link do app para o cliente
4. Cliente cria conta e usa

### Opção 3 — Stripe (automático, mais tarde)
- Integração direta com o sistema
- Bloqueia acesso automaticamente se não pagar

---

## 🎯 ESTRATÉGIA DE VENDAS

### Onde encontrar clientes:
- Grupos de WhatsApp de construtoras
- Facebook de engenheiros e mestres de obra
- LinkedIn (engenheiros, gestores de obras)
- Instagram com vídeos mostrando o app funcionando
- Indicação de cliente para cliente

### Argumento de venda:
> "Você perde ferramentas toda semana? Sabe quem está com cada EPI?
> Com o FerrPro você controla tudo pelo celular por menos de R$3/dia."

### Oferta de entrada:
- 14 dias grátis sem cartão
- Primeiro mês com 50% de desconto

---

## 📊 PROJEÇÃO FINANCEIRA

| Clientes | Plano | Receita/mês |
|----------|-------|-------------|
| 10       | R$49  | R$490       |
| 10       | R$99  | R$990       |
| 20       | R$99  | R$1.980     |
| 50       | R$99  | R$4.950     |
| 100      | R$99  | R$9.900     |

**Custo mensal:**
- Supabase Pro: ~R$120/mês (até 100k usuários)
- Netlify: Grátis
- **Total: ~R$120/mês**

---

## 🆘 SUPORTE

Se tiver dúvidas na configuração, volte aqui no chat!
