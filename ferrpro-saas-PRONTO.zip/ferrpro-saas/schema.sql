-- ════════════════════════════════════════════
-- FERRPRO — Schema Supabase
-- Cole esse SQL no SQL Editor do Supabase
-- ════════════════════════════════════════════

-- Habilitar RLS (Row Level Security)
-- Cada usuário vê APENAS os próprios dados

-- ── FERRAMENTAS ──
CREATE TABLE IF NOT EXISTS ferramentas (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  tipo text NOT NULL,
  nome text NOT NULL,
  qi integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE ferramentas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users see own ferramentas" ON ferramentas
  FOR ALL USING (auth.uid() = user_id);

-- ── EPIs ──
CREATE TABLE IF NOT EXISTS epis (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  cat text NOT NULL,
  nome text NOT NULL,
  ca text,
  qi integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE epis ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users see own epis" ON epis
  FOR ALL USING (auth.uid() = user_id);

-- ── FUNCIONÁRIOS ──
CREATE TABLE IF NOT EXISTS funcionarios (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  nome text NOT NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE funcionarios ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users see own funcionarios" ON funcionarios
  FOR ALL USING (auth.uid() = user_id);

-- ── RESPONSÁVEIS ──
CREATE TABLE IF NOT EXISTS responsaveis (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  nome text NOT NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE responsaveis ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users see own responsaveis" ON responsaveis
  FOR ALL USING (auth.uid() = user_id);

-- ── OBRAS ──
CREATE TABLE IF NOT EXISTS obras (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  nome text NOT NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE obras ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users see own obras" ON obras
  FOR ALL USING (auth.uid() = user_id);

-- ── MOVIMENTAÇÕES FERRAMENTAS ──
CREATE TABLE IF NOT EXISTS mov_ferramentas (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  tipo text NOT NULL CHECK (tipo IN ('saida', 'entrada')),
  ferramenta_nome text NOT NULL,
  tipo_ferramenta text,
  quantidade integer NOT NULL DEFAULT 1,
  funcionario text,
  obra text,
  responsavel text,
  obs text,
  data text,
  hora text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE mov_ferramentas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users see own mov_ferramentas" ON mov_ferramentas
  FOR ALL USING (auth.uid() = user_id);

-- ── MOVIMENTAÇÕES EPIs ──
CREATE TABLE IF NOT EXISTS mov_epis (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  tipo text NOT NULL CHECK (tipo IN ('saida', 'entrada')),
  epi_nome text NOT NULL,
  cat text,
  ca text,
  quantidade integer NOT NULL DEFAULT 1,
  funcionario text,
  obra text,
  responsavel text,
  obs text,
  data text,
  hora text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE mov_epis ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users see own mov_epis" ON mov_epis
  FOR ALL USING (auth.uid() = user_id);

-- ════════════════════════════════════════════
-- PRONTO! Execute esse SQL e as tabelas
-- serão criadas automaticamente.
-- ════════════════════════════════════════════
